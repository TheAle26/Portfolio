from django.apps import AppConfig


class AppfulboConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'AppFulbo'
    
    def ready(self):
        import AppFulbo.signals
